<?php
include 'db_connection.php';
session_start();

// Verificar que el usuario tenga el rol de cliente
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente') {
    echo "<script>
              alert('No tienes el rol de Cliente');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

// Verificar si se ha enviado el formulario con el motivo
if (isset($_POST['CodPedido']) && isset($_POST['Motivo'])) {
    $CodPedido = $_POST['CodPedido'];
    $Motivo = $_POST['Motivo'];
    $CodCliente = $_SESSION['user_id']; // Asumiendo que el CodCliente es el ID del cliente

    // Obtener el CodDelivery asociado a este pedido
    $sqlDelivery = "
        SELECT e.CodDelivery 
        FROM Entrega e 
        JOIN Pedido p ON e.CodPedido = p.CodPedido 
        JOIN Pago pa ON p.CodPago = pa.CodPago
        JOIN Carrito c ON pa.CodCarrito = c.CodCarrito 
        WHERE p.CodPedido = ? AND c.CodCliente = ?";
    
    $stmtDelivery = $conn->prepare($sqlDelivery);
    $stmtDelivery->bind_param("ii", $CodPedido, $CodCliente);
    $stmtDelivery->execute();
    $resultDelivery = $stmtDelivery->get_result();

    if ($resultDelivery->num_rows > 0) {
        $rowDelivery = $resultDelivery->fetch_assoc();
        $CodDelivery = $rowDelivery['CodDelivery'];

        // Verificar que se obtuvo un CodDelivery
        if (empty($CodDelivery)) {
            echo "<script>alert('No se pudo obtener el CodDelivery asociado a este pedido.');</script>";
            echo "<script>window.location.href = '../views/productos/vista_pedido_clientes.php';</script>";
            exit();
        }

        // Almacenar la devolución en la tabla devuelve
        $sql = "INSERT INTO devuelve (CodDelivery, CodPedido, Hora, Motivo) VALUES (?, ?, NOW(), ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iis", $CodDelivery, $CodPedido, $Motivo);

        // Ejecutar la inserción
        if ($stmt->execute()) {
            echo "<script>alert('Devolución registrada exitosamente.');</script>";
        } else {
            // Mostrar error en la inserción
            echo "<script>alert('Error al registrar la devolución: " . $stmt->error . "');</script>";
        }
    } else {
        echo "<script>alert('No se encontró el CodDelivery asociado a este pedido.');</script>";
    }

    echo "<script>window.location.href = '../views/productos/vista_pedido_clientes.php';</script>";
} else {
    echo "<script>alert('Parámetros inválidos.');</script>";
    echo "<script>window.location.href = '../views/productos/vista_pedido_clientes.php';</script>";
}
?>
