<?php
include 'db_connection.php';
$comunidad_id = $_GET['id'];

$sql = "DELETE FROM comunidad WHERE CodComunidad = $comunidad_id";
if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Comunidad eliminada exitosamente'); window.location.href = '../views/dashbord_MunayArt';</script>";
} else {
    echo "Error al eliminar la comunidad: " . $conn->error;
}

$conn->close();
?>
