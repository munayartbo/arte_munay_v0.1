<?php
session_start();

// Obtener el rol de la sesión, si existe
if (isset($_SESSION['rol'])) {
    $rol = $_SESSION['rol'];
} else {
    $rol = 'cliente';
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tu página web</title>
    <link rel="stylesheet" href="views/css/styles.css">
    <script src="views/js/script.js"></script>

    <style>
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
        }

        main {
            margin-top: 120px;
        }

        iframe {
            width: 100%;
            border: none;
            overflow: hidden;
        }

        .chatbot-container {
            width: 400px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            position: fixed;
            bottom: 100px;
            right: 20px;
            display: none;
            z-index: 1001;
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }

        .icono-chatbot {
            width: 100px;
            height: 100px;
        }

        .chat-box {
            height: 300px;
            overflow-y: auto;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .user-message {
            text-align: right;
            color: #333;
            margin: 5px;
        }

        .chatbot-response {
            text-align: left;
            color: #D64045;
            margin: 5px;
        }

        #user-input {
            width: calc(100% - 80px);
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            outline: none;
        }

        .chatbot-button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background-color: #D64045;
            color: white;
            cursor: pointer;
            outline: none;
        }

        #chatbot-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background-color: #D64045;
            color: white;
            cursor: pointer;
            z-index: 1001;
        }


        /* Estilos específicos para el iframe con id 'encabezado-iframe' */
        #encabezado-iframe {
            width: 100%;
            max-width: 100%;
        }

        /* Ajusta la altura en pantallas más pequeñas */
        @media (max-width: 480px) {
            #encabezado-iframe {
                height: 500px;
                /* Ajuste de altura en móviles */
            }
        }
    </style>
</head>

<body>

    <!-- Botón para abrir/cerrar el chatbot -->
    <button onclick="toggleChatbot()" id="chatbot-toggle">Chat</button>

    <!-- Contenedor del chatbot -->
    <div class="chatbot-container" id="chatbot">
        <div class="header">
            <img src="imagenes/chat.webp" alt="Icono del chatbot" class="icono-chatbot">
            <h2>Chat-Munay</h2>
        </div>
        <div class="chat-box" id="chat-box">
        </div>
        <input type="text" id="user-input" placeholder="Escribe tu pregunta..." />
        <button onclick="enviarMensaje()" class="chatbot-button">Enviar</button>
    </div>

    <!-- ENCABEZADO -->
    <header>
        <br>
        <div style="width: 100%; height: auto;">
            <iframe id="encabezado-iframe" src="views/encabezado.php" scrolling="no" frameborder="0"
                style="width: 100%; height: 110px;"></iframe>
        </div>
    </header>
    <br><br>

    
    




    <!-- CUERPO -->
    <main>
        <iframe id="contenido" src="views/inicio.php" frameborder="0" style="width: 100%;"></iframe>
    </main>

    <!-- FOOTER -->
    <footer>
        <div class="container">
            <div class="foo-row">
                <div class="foo-col">
                    <h2>Suscríbete <br>a nuestro newsletter</h2>
                    <form action="" method="GET">
                        <div class="f-input">
                            <input type="text" placeholder="Ingrese su correo">
                            <button type="submit" class="hm-btn-round btn-primary"><i
                                    class="far fa-paper-plane"></i></button>
                        </div>
                    </form>
                </div>
                <div class="foo-col">
                    <ul>
                        <li><a href="http://">Productos</a></li>
                        <li><a href="http://">Campañas</a></li>
                        <li><a href="http://">Nosotros</a></li>
                        <li><a href="http://">Contacto</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <div class="foo-copy">
        <div class="container">
            <p>MunayArt 2024 © Todos los derechos reservados</p>
        </div>
    </div>

    <!-- Animaciones AOS -->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script src="views/js/app.js"></script>
    <script>
        AOS.init({ duration: 1200 });
    </script>

    <!-- Script para ajustar la altura del iframe -->
    <script>
        window.addEventListener('message', function (event) {
            if (!isNaN(event.data)) {
                var iframe = document.getElementById('contenido');
                iframe.style.height = event.data + 'px';
            }
        });

        function ajustarAlturaIframe() {
            const iframe = document.getElementById('contenido');
            try {
                iframe.style.height = iframe.contentWindow.document.body.scrollHeight + 'px';
            } catch (error) {
                console.error("Error ajustando altura del iframe:", error);
            }
        }
    </script>

    <!-- Script para el chatbot -->
    <script>
        function toggleChatbot() {
            var chatbot = document.getElementById("chatbot");
            chatbot.style.display = chatbot.style.display === "none" || chatbot.style.display === "" ? "block" : "none";
        }

        function enviarMensaje() {
            var message = document.getElementById("user-input").value;
            if (message.trim() === "") {
                alert("Por favor, ingresa un mensaje.");
                return;
            }
            fetch('controllers/chatbot_controller.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'message=' + encodeURIComponent(message) + '&rol=' + encodeURIComponent("<?php echo $rol; ?>")
            })
                .then(response => response.json())
                .then(data => {
                    var chatBox = document.getElementById("chat-box");
                    chatBox.innerHTML += "<div class='user-message'>" + message + "</div>";
                    chatBox.innerHTML += "<div class='chatbot-response'>" + data.response + "</div>";
                    document.getElementById("user-input").value = "";
                    chatBox.scrollTop = chatBox.scrollHeight;
                })
                .catch(error => console.log("Error: ", error));
        }
    </script>
</body>

</html>