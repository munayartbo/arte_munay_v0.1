<?php
// Incluir el archivo de conexión a la base de datos
include 'db_connection.php';

// Ejecutar la consulta para contar el número de usuarios
$sql = "SELECT COUNT(DISTINCT u.CodUsuario) AS totalUsuarios FROM usuario u";
$result = $conn->query($sql);

// Verificar si hay resultados
if ($result->num_rows > 0) {
    // Obtener el total de usuarios desde el resultado
    $row = $result->fetch_assoc();
    $totalUsuarios = $row['totalUsuarios'];
} else {
    $totalUsuarios = 0; // En caso de que no haya registros
}

// Consulta para el ingreso total generado
$sqlIngresosGenerados = "SELECT SUM(Total) AS ingresosGenerados FROM Pago";
$resultIngresos = $conn->query($sqlIngresosGenerados);
$ingresosGenerados = $resultIngresos->fetch_assoc()['ingresosGenerados'] ?? 0;

// Consulta para total de ventas diarias
$sqlVentasDiarias = "SELECT SUM(p.Total) AS ventasDiarias
                     FROM Pago p
                     JOIN Pedido pe ON p.CodPago = pe.CodPago
                     WHERE DATE(pe.Fecha) = CURDATE()";
$resultDiarias = $conn->query($sqlVentasDiarias);
$ventasDiarias = $resultDiarias->fetch_assoc()['ventasDiarias'] ?? 0;

// Consulta para total de ventas semanales
$sqlVentasSemanales = "SELECT SUM(p.Total) AS ventasSemanales
                       FROM Pago p
                       JOIN Pedido pe ON p.CodPago = pe.CodPago
                       WHERE YEARWEEK(pe.Fecha, 1) = YEARWEEK(CURDATE(), 1)";
$resultSemanales = $conn->query($sqlVentasSemanales);
$ventasSemanales = $resultSemanales->fetch_assoc()['ventasSemanales'] ?? 0;

// Consulta para total de ventas mensuales
$sqlVentasMensuales = "SELECT SUM(p.Total) AS ventasMensuales
                       FROM Pago p
                       JOIN Pedido pe ON p.CodPago = pe.CodPago
                       WHERE MONTH(pe.Fecha) = MONTH(CURDATE()) AND YEAR(pe.Fecha) = YEAR(CURDATE())";
$resultMensuales = $conn->query($sqlVentasMensuales);
$ventasMensuales = $resultMensuales->fetch_assoc()['ventasMensuales'] ?? 0;

// Consulta para obtener los productos más vendidos
$sqlProductosMasVendidos = "SELECT prod.CodProducto, prod.Nombre, prod.Tipo, prod.Precio, prod.Imagen, SUM(i.Cantidad) AS totalVendidos
                            FROM Producto prod
                            JOIN Incluye i ON prod.CodProducto = i.CodProducto
                            GROUP BY prod.CodProducto
                            ORDER BY totalVendidos DESC
                            LIMIT 5";
$resultProductosMasVendidos = $conn->query($sqlProductosMasVendidos);


// total de pedidos:

$sqlTotalPed = "SELECT  COUNT(p.CodPedido) as totalPedidos 
    FROM Pedido p";

$resultTotalPed = $conn->query($sqlTotalPed);
$TotalPed = $resultTotalPed->fetch_assoc()['totalPedidos'] ?? 0;





//=======================
//grafico 2
$queryPedido = "
    SELECT Estado, COUNT(*) as total 
    FROM Pedido 
    WHERE Estado IN ('Entregado', 'En Camino', 'Pendiente')
    GROUP BY Estado;
";

$result = $conn->query($queryPedido);



// Variables para almacenar los datos
$entregado = 0;
$enCamino = 0;
$pendiente = 0;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row['Estado'] === 'Entregado') {
            $entregado = $row['total'];
        } elseif ($row['Estado'] === 'En Camino') {
            $enCamino = $row['total'];
        } elseif ($row['Estado'] === 'Pendiente') {
            $pendiente = $row['total'];
        }
    }
}

//grafico 3
// Consultas para contar cada tipo de usuario
// Ejemplo de consulta para Deliveries
$sqlDelivery = "SELECT COUNT(DISTINCT d.CodDelivery) AS totalDeliveries FROM delivery d";
$sqlCliente = "SELECT COUNT(DISTINCT c.CodCliente) AS totalClientes FROM cliente c";
$sqlArtesano = "SELECT COUNT(DISTINCT a.CodArtesano) AS totalArtesanos FROM artesano a";
$sqlAdmin = "SELECT COUNT(DISTINCT ad.CodAdmi) AS totalAdministradores FROM administrador ad";

// Ejecutar las consultas y obtener los resultados
$resultDelivery = $conn->query($sqlDelivery);
$resultCliente = $conn->query($sqlCliente);
$resultArtesano = $conn->query($sqlArtesano);
$resultAdmin = $conn->query($sqlAdmin);

// Obtener los totales de cada tipo
$totalDeliveries = ($resultDelivery->num_rows > 0) ? $resultDelivery->fetch_assoc()['totalDeliveries'] : 0;
$totalClientes = ($resultCliente->num_rows > 0) ? $resultCliente->fetch_assoc()['totalClientes'] : 0;
$totalArtesanos = ($resultArtesano->num_rows > 0) ? $resultArtesano->fetch_assoc()['totalArtesanos'] : 0;
$totalAdministradores = ($resultAdmin->num_rows > 0) ? $resultAdmin->fetch_assoc()['totalAdministradores'] : 0;




// Apartado de productos

// Consulta para obtener el estado de inventario
$sqlEstadoInventario = "SELECT prod.CodProducto, prod.Nombre, prod.Tipo, prod.Precio, prod.Imagen, inv.Cantidad,
                        CASE
                            WHEN inv.Cantidad = 0 THEN 'Agotado'
                            WHEN inv.Cantidad < 10 THEN 'Bajo Inventario'
                            ELSE 'En Stock'
                        END AS Estado
                        FROM Producto prod
                        JOIN Inventario inv ON prod.CodProducto = inv.CodProducto";
$resultEstadoInventario = $conn->query($sqlEstadoInventario);

// Variable para almacenar productos con bajo inventario o agotados
$productosNotificacion = [];

// Verificamos si hay productos agotados o en bajo inventario
while ($producto = $resultEstadoInventario->fetch_assoc()) {
    if ($producto['Estado'] == 'Bajo Inventario' || $producto['Estado'] == 'Agotado') {
        $productosNotificacion[] = ['nombre' => $producto['Nombre'], 'estado' => $producto['Estado']];
    }
}

// Reseteamos el puntero para reutilizar el resultado en la tabla
$resultEstadoInventario->data_seek(0);


/*-------------------------------admin comunidades----------------------------------*/
// Consultar todos los usuarios (Clientes, Artesanos, Deliverys)
$sql_usuarios = "
    SELECT u.CodUsuario, u.Nombre, u.Apellido, u.Email, u.User, u.FechaNac, u.Celular,
           c.CodCliente, a.CodArtesano, a.Descripcion, a.AniosExp, a.FechaRegistro, a.Imagen, 
           d.CodDelivery, d.TipoVehiculo, d.Placa, d.ZonaCobertura, d.HoraIngreso, d.HoraSalida
    FROM Usuario u
    LEFT JOIN Cliente c ON u.CodUsuario = c.CodCliente
    LEFT JOIN Artesano a ON u.CodUsuario = a.CodArtesano
    LEFT JOIN Delivery d ON u.CodUsuario = d.CodDelivery
";
$result_usuarios = $conn->query($sql_usuarios);

// Consultar todas las promociones
$sql_promociones = "SELECT CodPromocion, Titulo, Descripcion, FechaInicio, FechaFin FROM promocion";
$result_promociones = $conn->query($sql_promociones);


/*-------------------------------entregas----------------------------------*/
// Consulta para obtener los pedidos pendientes
$sql_pedidos = "
    SELECT p.CodPedido, pa.CodCarrito, p.Estado, pa.Total, c.Fecha, u.Departamento, s.Nombre, s.Apellido
    FROM Pedido p
    JOIN Pago pa ON p.CodPago = pa.CodPago
    JOIN Carrito c ON pa.CodCarrito = c.CodCarrito
    JOIN Cliente cl ON c.CodCliente = cl.CodCliente
    JOIN Usuario s ON cl.CodCliente = s.CodUsuario
    JOIN Ubicacion u ON u.CodUbicacion = p.CodUbicacion
    WHERE p.Estado IN ('Pendiente')
";
$result_pedidos = $conn->query($sql_pedidos);

// Consulta para obtener deliverys disponibles
$sql_deliverys = "
    SELECT d.CodDelivery, u.Nombre, u.Apellido, d.TipoVehiculo, d.ZonaCobertura, d.HoraIngreso, d.HoraSalida
    FROM Delivery d
    JOIN Usuario u ON d.CodDelivery = u.CodUsuario
    WHERE 
    (
        (d.HoraIngreso <= NOW() AND d.HoraSalida >= NOW()) -- Turnos normales
        OR 
        (d.HoraIngreso > d.HoraSalida AND (d.HoraIngreso <= NOW() OR d.HoraSalida >= NOW())) -- Turnos que cruzan la medianoche
    )
";
$result_deliverys = $conn->query($sql_deliverys);
?>



<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>MunayArt Dashboard</title>
    <style>
        .alerta {
            background-color: #ffcccc;
            color: #d9534f;
            padding: 10px;
            margin: 15px 0;
            border: 1px solid #d9534f;
            border-radius: 5px;
        }

        .alerta-inventario {
            background-color: #ffebcc;
            color: #d9534f;
            font-weight: bold;
        }


        .notificacion {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #ffebcc;
            color: #d9534f;
            padding: 15px;
            border: 1px solid #d9534f;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            width: 300px;
        }

        .notificacion p {
            font-weight: bold;
            margin: 0;
        }

        .notificacion ul {
            margin: 10px 0 0;
            padding-left: 20px;
        }

        .notificacion button {
            background-color: #d9534f;
            color: #fff;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            margin-top: 10px;
            border-radius: 3px;
        }


        /*admin comunidades*/



        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-family: Arial, sans-serif;
            font-size: 16px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: cadetblue;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        /* Estilos para el enlace de eliminación */
        .delete-link {
            color: white;
            background-color: #f44336;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .delete-link:hover {
            background-color: #d32f2f;
        }

        form {
            max-width: 500px;
            margin: 20px 0;
            font-family: Arial, sans-serif;
            font-size: 16px;
        }

        label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin: 5px 0 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }

        /* Estilos para la lista de comunidades */
        ul {
            list-style-type: none;
            padding: 0;
        }

        ul li {
            padding: 10px;
            background-color: #f2f2f2;
            margin-bottom: 8px;
            border-radius: 5px;
        }

        ul li a {
            color: #f44336;
            text-decoration: none;
            font-weight: bold;
        }

        ul li a:hover {
            color: #d32f2f;
        }
    </style>
</head>

<body>

    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class="bx bxs-smile"></i>
            <span class="text">MunayArt</span>
        </a>

        <ul class="side-menu top">
            <li class="active">
                <a href="#" data-section="dashboard">
                    <i class="bx bxs-dashboard"></i>
                    <span class="text">Tablero</span>
                </a>
            </li>
            <li>
                <a href="#" data-section="usuario">
                    <i class="bx bxs-user"></i>
                    <span class="text">Usuario</span>
                </a>
            </li>
            <li>
                <a href="#" data-section="productos">
                    <i class="bx bxs-doughnut-chart"></i>
                    <span class="text">Productos</span>
                </a>
            </li>
            <li>
                <a href="#" data-section="comunidades">
                    <i class="bx bxs-group"></i>
                    <span class="text">Comunidades</span>
                </a>
            </li>
            <li>
                <a href="#" data-section="entregas">
                    <i class="bx bxs-truck"></i>
                    <span class="text">Entregas</span>
                </a>
            </li>
        </ul>

        <ul class="side-menu">
            <li>
                <a href="#" data-section="parametros">
                    <i class="bx bxs-cog"></i>
                    <span class="text">Parámetros</span>
                </a>
            </li>
            <li>
                <a href="../logout.php" class="logout" data-section="logout">
                    <i class="bx bxs-log-out-circle"></i>
                    <span class="text">Desconectar</span>
                </a>
            </li>

        </ul>
    </section>
    <!-- SIDEBAR END -->

    <!-- Contenido -->
    <section id="content">

        <nav>
            <i class="bx bx-menu"></i>
            <a href="#" class="nav-link">MunayArt Dashboard</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="buscar...">
                    <button type="submit" class="search-btn"><i class="bx bx-search"></i> </button>

                </div>
            </form>
            <input type="checkbox" id="swith-mode" hidden>
            <label for="swith-mode" class="swith-mode"></label>
            <a href="#" class="notification">
                <i class="bx bxs-bell"></i>
                <span class="num">3</span>
            </a>
            <a href="#" class="profile">
                <img src="img/profil.png" alt="Photo profil">
            </a>
        </nav>

        <!-- Main content -->
        <main>
            <!-- Secciones de contenido -->
            <div id="dashboard" class="section">
                <h2>Bienvenido al Tablero</h2>

                <ul class="box-info">
                    <li>
                        <button onclick="showContent('ingresos')"><i class="bx bxs-dollar-circle"></i> Ingresos</button>
                        <span class="text">
                            <h3>Bs.<?php echo $ingresosGenerados; ?></h3>
                            <p>Ingresos Generados</p>
                        </span>
                    </li>
                    <li>
                        <button onclick="showContent('pedidos')"><i class="bx bxs-calendar-check"></i> Pedidos</button>
                        <span class="text">
                            <h3><?php echo $TotalPed; ?></h3>
                            <p>Numero Pedidos</p>
                        </span>
                    </li>
                    <li>
                        <button onclick="showContent('usuarios')"><i class="bx bxs-group"></i> Usuarios</button>
                        <span class="text">
                            <h3><?php echo $totalUsuarios; ?></h3><!-- boton-->
                            <p>Usuarios</p>
                        </span>
                    </li>
                </ul>

                <!-- Contenedor único para mostrar el contenido dinámico -->
                <div id="content-display" class="content-box">
                    <!-- Aquí se cargará el contenido de cada opción seleccionada -->
                </div>

                <div class="table-data">
                    <div class="order">
                        <div class="head">
                            <h3>Pedidos recientes</h3>
                            <i class="bx bx-search"></i>
                            <i class="bx bx-filter"></i>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Usuario</th>
                                    <th>Fecha de pedido</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <img src="img/p1.png" alt="Profil 1">
                                        <p>Marie</p>
                                    </td>
                                    <td>14-08-2024</td>
                                    <td><span class="status completed">Entregado</span></td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="img/p2.png" alt="Profil 2">
                                        <p>Bineta</p>
                                    </td>
                                    <td>14-08-2024</td>
                                    <td><span class="status pending">Enviado</span></td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="img/p3.png" alt="Profil 3">
                                        <p>Ibrahim</p>
                                    </td>
                                    <td>14-08-2024</td>
                                    <td><span class="status process">En proceso</span></td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="img/p4.png" alt="Profil 4">
                                        <p>Maimouna</p>
                                    </td>
                                    <td>14-08-2024</td>
                                    <td><span class="status pending">Pendientes</span></td>
                                </tr>

                            </tbody>
                        </table>
                    </div>


                    <div class="todo">
                        <div class="head">
                            <h3>Lista de verificación</h3>
                            <i class="bx bx-plus"></i>
                            <i class="bx bx-filter"></i>
                        </div>
                        <ul class="todo-list">
                            <li class="completed">
                                <p>A Faire</p>
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </li>
                            <li class="not-completed">
                                <p>A Faire</p>
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </li>
                            <li class="completed">
                                <p>A Faire</p>
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </li>
                            <li class="not-completed">
                                <p>A Faire</p>
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </li>
                            <li class="completed">
                                <p>A Faire</p>
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div id="usuario" class="section" style="display: none;">
                <h2>Sección de Usuario</h2>
                <!-- Sección de Usuarios -->
                <h2>Lista de Usuarios</h2>
                <?php
                if ($result_usuarios->num_rows > 0) {
                    echo "<table border='1'>
                <thead>
                    <tr>
                        <th>CodUsuario</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>";

                    while ($row = $result_usuarios->fetch_assoc()) {
                        $rol = '';

                        if (!empty($row['CodCliente'])) {
                            $rol = 'Cliente';
                        } elseif (!empty($row['CodArtesano'])) {
                            $rol = 'Artesano';
                        } elseif (!empty($row['CodDelivery'])) {
                            $rol = 'Delivery';
                        } else {
                            $rol = 'Administrador';
                        }

                        echo "<tr>
                    <td>{$row['CodUsuario']}</td>
                    <td>{$row['Nombre']}</td>
                    <td>{$row['Apellido']}</td>
                    <td>{$row['Email']}</td>
                    <td>$rol</td>
                    
                    <td><a href='../../controllers/eliminar_usuario.php?cod_usuario={$row['CodUsuario']}' onclick='return confirm(\"¿Estás seguro de que deseas eliminar este usuario?\")'>Eliminar</a></td>
                  </tr>";
                    }

                    echo "</tbody></table>";
                } else {
                    echo "<p>No se encontraron usuarios.</p>";
                }
                ?>
            </div>

            <div id="productos" class="section" style="display: none;">
                <h2>Sección de Productos</h2>
                <div class="table-data">
                    <div class="order">
                        <div class="head">
                            <h3>Productos Más Vendidos</h3>
                            <i class="bx bx-search"></i>
                            <i class="bx bx-filter"></i>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Imagen</th>
                                    <th>CodProducto</th>
                                    <th>Nombre</th>
                                    <th>Tipo</th>
                                    <th>Precio</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($producto = $resultProductosMasVendidos->fetch_assoc()): ?>
                                    <tr>
                                        <td><img src="img/<?php echo $producto['Imagen']; ?>"
                                                alt="<?php echo $producto['Nombre']; ?>"></td>
                                        <td><?php echo $producto['CodProducto']; ?></td>
                                        <td><?php echo $producto['Nombre']; ?></td>
                                        <td><?php echo $producto['Tipo']; ?></td>
                                        <td>$<?php echo $producto['Precio']; ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>



                <div class="table-data">
                    <div class="order">
                        <div class="head">
                            <h3>Estado del Inventario</h3>
                            <i class="bx bx-search"></i>
                            <i class="bx bx-filter"></i>
                        </div>

                        <!-- Notificación emergente de bajo inventario y productos agotados -->
                        <div class="notificacion" id="notificacionInventario">
                            <p>Productos con bajo inventario:</p>
                            <ul style="none">
                                <?php foreach ($productosNotificacion as $producto): ?>
                                    <li><?php echo $producto['nombre'] . " - " . $producto['estado']; ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <button onclick="cerrarNotificacion()">Cerrar</button>
                        </div>
                        <script>

                            function cerrarNotificacion() {
                                var notificacion = document.getElementById("notificacionInventario");
                                if (notificacion) {
                                    notificacion.style.display = "none";
                                } else {
                                    console.log("Elemento no encontrado.");
                                }
                            }
                            document.addEventListener("DOMContentLoaded", function () {
                                function cerrarNotificacion() {
                                    var notificacion = document.getElementById("notificacionInventario");
                                    if (notificacion) {
                                        notificacion.style.display = "none";
                                    }
                                }

                                // Aquí puedes añadir el resto de la funcionalidad
                            });


                        </script>


                        <!-- Tabla de inventario -->
                        <table>
                            <thead>
                                <tr>
                                    <th>Imagen</th>
                                    <th>CodProducto</th>
                                    <th>Nombre</th>
                                    <th>Tipo</th>
                                    <th>Precio</th>
                                    <th>Cantidad</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($producto = $resultEstadoInventario->fetch_assoc()): ?>
                                    <tr
                                        class="<?php echo ($producto['Estado'] == 'Bajo Inventario' || $producto['Estado'] == 'Agotado') ? 'alerta-inventario' : ''; ?>">
                                        <td><img src="img/<?php echo $producto['Imagen']; ?>"
                                                alt="<?php echo $producto['Nombre']; ?>"></td>
                                        <td><?php echo $producto['CodProducto']; ?></td>
                                        <td><?php echo $producto['Nombre']; ?></td>
                                        <td><?php echo $producto['Tipo']; ?></td>
                                        <td>$<?php echo $producto['Precio']; ?></td>
                                        <td><?php echo $producto['Cantidad']; ?></td>
                                        <td><?php echo $producto['Estado']; ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Sección de Promociones -->
                <h2>Lista de Promociones</h2>
                <?php
                // Mostrar tabla de promociones
                if ($result_promociones->num_rows > 0) {
                    echo "<table border='1'>
            <thead>
                <tr>
                    <th>CodPromocion</th>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Fecha Inicio</th>
                    <th>Fecha Fin</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>";

                    while ($row = $result_promociones->fetch_assoc()) {
                        echo "<tr>
                <td>{$row['CodPromocion']}</td>
                <td>{$row['Titulo']}</td>
                <td>{$row['Descripcion']}</td>
                <td>{$row['FechaInicio']}</td>
                <td>{$row['FechaFin']}</td>
                <td><a href='../../controllers/eliminar_promocion.php?cod_promocion={$row['CodPromocion']}' onclick='return confirm(\"¿Estás seguro de que deseas eliminar esta promoción?\")'>Eliminar</a></td>
              </tr>";
                    }

                    echo "</tbody></table>";
                } else {
                    echo "<p>No se encontraron promociones.</p>";
                }
                ?>

                <h2>Añadir Promoción</h2>
                <form action="../../controllers/procesar_promocion.php" method="POST">
                    <label for="titulo">Título:</label>
                    <input type="text" name="titulo" required><br>

                    <label for="descripcion">Descripción:</label>
                    <textarea name="descripcion" required></textarea><br>

                    <label for="fecha_inicio">Fecha Inicio:</label>
                    <input type="date" name="fecha_inicio" required>

                    <label for="fecha_fin">Fecha Fin:</label>
                    <input type="date" name="fecha_fin" required>

                    <label for="producto">Producto:</label>
                    <select name="producto" required>
                        <?php
                        // Consultar productos para la promoción
                        include '../../controllers/db_connection.php'; // Conexión a la base de datos
                        $sql_productos = "SELECT CodProducto, Nombre FROM Producto";
                        $result_productos = $conn->query($sql_productos);

                        if ($result_productos === FALSE) {
                            echo "<option value=''>Error en la consulta</option>";
                        } else {
                            if ($result_productos->num_rows > 0) {
                                while ($row = $result_productos->fetch_assoc()) {
                                    echo "<option value='{$row['CodProducto']}'>{$row['Nombre']}</option>";
                                }
                            } else {
                                echo "<option value=''>No hay productos disponibles</option>";
                            }
                        }
                        ?>
                    </select><br>

                    <input type="submit" value="Añadir Promoción">
                </form>

            </div>
            <div id="comunidades" class="section" style="display: none;">
                <h2>Sección de Comunidades</h2>
                <h2>Subir Comunidades</h2>
                <!-- Formulario para agregar comunidades -->
                <form action="../../controllers/procesar_comunidad.php" method="post">
                    <label for="nombre">Nombre de la Comunidad:</label>
                    <input type="text" id="nombre" name="nombre" required><br>

                    <label for="habitantes">Número de Habitantes:</label>
                    <input type="number" id="habitantes" name="habitantes" required><br>

                    <!-- Aquí irá la lógica para seleccionar el administrador (si lo deseas) -->
                    <label for="admin">Administrador (ID):</label>
                    <input type="text" id="admin" name="admin" required><br>

                    <button type="submit">Agregar Comunidad</button>
                </form>

                <!-- Mostrar las comunidades existentes -->
                <h2>Lista de Comunidades</h2>
                <ul>
                    <?php

                    $sql = "SELECT * FROM comunidad";
                    $result = $conn->query($sql);

                    while ($row = $result->fetch_assoc()) {
                        echo "<li>{$row['Nombre']} - Habitantes: {$row['NroHabitantes']} - <a href='../../controllers/eliminar_comunidad.php?id={$row['CodComunidad']}' onclick='return confirm(\"¿Estás seguro de que deseas eliminar esta comunidad?\")'>Eliminar</a></li>";
                    }

                    $conn->close();
                    ?>
                </ul>
            </div>

            <!--jmqm-->
            <div id="entregas" class="section" style="display: none;">
                <h2>Sección de Entregas</h2>
                <h2>Lista de Pedidos Realizados</h2>
                <div class="table-container">
                    <?php if ($result_pedidos->num_rows > 0): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Código Pedido</th>
                                    <th>Cliente</th>
                                    <th>Fecha</th>
                                    <th>Ubicación</th>
                                    <th>Estado</th>
                                    <th>Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result_pedidos->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['CodPedido']); ?></td>
                                        <td><?php echo htmlspecialchars($row['Nombre']) . ' ' . htmlspecialchars($row['Apellido']); ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($row['Fecha']); ?></td>
                                        <td><?php echo htmlspecialchars($row['Departamento']); ?></td>
                                        <td><?php echo htmlspecialchars($row['Estado']); ?></td>
                                        <td><a
                                                href="../asignar_delivery.php?cod_pedido=<?php echo urlencode($row['CodPedido']); ?>">Asignar
                                                Delivery</a></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No se encontraron pedidos.</p>
                    <?php endif; ?>
                </div>

                <h2>Lista de Deliverys Disponibles</h2>
                <div class="table-container">
                    <?php if ($result_deliverys->num_rows > 0): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Código Delivery</th>
                                    <th>Nombre</th>
                                    <th>Tipo Vehículo</th>
                                    <th>Zona de Cobertura</th>
                                    <th>Horario</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result_deliverys->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['CodDelivery']); ?></td>
                                        <td><?php echo htmlspecialchars($row['Nombre']) . ' ' . htmlspecialchars($row['Apellido']); ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($row['TipoVehiculo']); ?></td>
                                        <td><?php echo htmlspecialchars($row['ZonaCobertura']); ?></td>
                                        <td><?php echo htmlspecialchars($row['HoraIngreso']) . ' - ' . htmlspecialchars($row['HoraSalida']); ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No hay deliverys disponibles en este momento.</p>
                    <?php endif; ?>
                </div>

            </div>
            <div id="parametros" class="section" style="display: none;">
                <h2>Sección de Parámetros</h2>
                <p>Configuración y ajustes de la plataforma.</p>
            </div>
            <div id="logout" class="section" style="display: none;">
                <h2>Desconectar</h2>
                <p>¿Seguro que quieres cerrar sesión en la plataforma?</p>
                <a href="../logout.php" class="logout" data-section="logout">
                    <i class="bx bxs-log-out-circle"></i>
                    <span class="text">Desconectar</span>
                </a>
            </div>
        </main>
    </section>
    <!-- Contenido END -->
    <script src="script.js"></script>

    <!-- JavaScript para cambiar el contenido -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Selecciona todos los enlaces del menú
            const menuLinks = document.querySelectorAll(".side-menu a");

            // Añade un evento de clic a cada enlace
            menuLinks.forEach(link => {
                link.addEventListener("click", function (event) {
                    event.preventDefault(); // Evita el comportamiento de navegación

                    // Quita la clase "active" de todos los enlaces
                    menuLinks.forEach(link => link.parentElement.classList.remove("active"));

                    // Añade la clase "active" al enlace clicado
                    this.parentElement.classList.add("active");

                    // Oculta todas las secciones
                    document.querySelectorAll("main .section").forEach(section => {
                        section.style.display = "none";
                    });

                    // Muestra la sección correspondiente al enlace clicado
                    const sectionId = this.getAttribute("data-section");
                    document.getElementById(sectionId).style.display = "block";
                });
            });
        });
    </script>

    <!--graficos-->

    <!--opcioned de graficos-->
    <script>
        function showContent(option) {
            const contentDisplay = document.getElementById('content-display');

            // Definimos el contenido para cada opción
            let content = '';

            if (option === 'ingresos') {
                content = `<canvas id="ventasChart" width="1000" height="400"></canvas>`;
            } else if (option === 'pedidos') {
                content = `<canvas id="pedidosChart" width="1000" height="400"></canvas>`;
            } else if (option === 'usuarios') {
                content = `<canvas id="usuariosChart" width="1000" height="400"></canvas>`;
            }

            // Actualizamos el contenido del contenedor
            contentDisplay.innerHTML = content;

            // Usamos setTimeout para asegurarnos de que el canvas esté disponible en el DOM
            if (option === 'ingresos') {
                initVentasChart();
            } else if (option === 'pedidos') {
                setTimeout(initPedidosChart, 100); // Espera un poco antes de inicializar
            } else if (option === 'usuarios') {
                setTimeout(initUsuariosChart, 100); // Espera un poco antes de inicializar
            }
        }
        window.onload = function () {
            showContent('ingresos');
        }


    </script>


    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!--1-->
    <script>
        function initVentasChart() {
            const ctx = document.getElementById('ventasChart').getContext('2d');
            const ventasDiarias = <?php echo json_encode($ventasDiarias); ?>;
            const ventasSemanales = <?php echo json_encode($ventasSemanales); ?>;
            const ventasMensuales = <?php echo json_encode($ventasMensuales); ?>;

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Ventas Diarias', 'Ventas Semanales', 'Ventas Mensuales'],
                    datasets: [{
                        label: 'Total de Ventas (Bs)',
                        data: [ventasDiarias, ventasSemanales, ventasMensuales],
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.5)',
                            'rgba(54, 162, 235, 0.5)',
                            'rgba(255, 99, 132, 0.5)'
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 99, 132, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Total de Ventas Diarias, Semanales y Mensuales'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    </script>

    <script>
        function initPedidosChart() {
            const ctx = document.getElementById('pedidosChart')?.getContext('2d');
            if (!ctx) return; // Salir si el canvas no está listo

            // Datos obtenidos desde PHP
            const entregado = <?php echo json_encode($entregado); ?>;
            const enCamino = <?php echo json_encode($enCamino); ?>;
            const pendiente = <?php echo json_encode($pendiente); ?>;

            // Crear el gráfico
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Entregado', 'En Camino', 'Pendiente'],
                    datasets: [{
                        label: 'Estado de Pedidos',
                        data: [entregado, enCamino, pendiente],
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.5)',  // Color para "Entregado"
                            'rgba(255, 159, 64, 0.5)',  // Color para "En Camino"
                            'rgba(255, 205, 86, 0.5)'   // Color para "Pendiente"
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)',
                            'rgba(255, 159, 64, 1)',
                            'rgba(255, 205, 86, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Estado de Pedidos'
                        }
                    }
                }
            });
        }
    </script>


    <script>
        function initUsuariosChart() {
            const ctx = document.getElementById('usuariosChart')?.getContext('2d');
            if (!ctx) return; // Salir si el canvas no está listo

            // Datos obtenidos desde PHP
            const usuariosData = [
                <?php echo json_encode($totalDeliveries); ?>,
                <?php echo json_encode($totalClientes); ?>,
                <?php echo json_encode($totalArtesanos); ?>,
                <?php echo json_encode($totalAdministradores); ?>
            ];

            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Deliveries', 'Clientes', 'Artesanos', 'Administradores'],
                    datasets: [{
                        label: 'Usuarios por Tipo',
                        data: usuariosData,
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.5)',  // Color para "Deliveries"
                            'rgba(54, 162, 235, 0.5)',  // Color para "Clientes"
                            'rgba(255, 159, 64, 0.5)',  // Color para "Artesanos"
                            'rgba(153, 102, 255, 0.5)'  // Color para "Administradores"
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 159, 64, 1)',
                            'rgba(153, 102, 255, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Usuarios por Tipo'
                        }
                    }
                }
            });
        }
    </script>

    <!--Apartado productos-->






</body>

</html>