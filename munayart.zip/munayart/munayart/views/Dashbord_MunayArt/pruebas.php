<?php
// Incluir el archivo de conexión a la base de datos
include 'db_connection.php';

// Ejecutar la consulta para contar el número de clientes
$sql = "SELECT COUNT(DISTINCT c.CodCliente) AS totalClientes FROM cliente c";
$result = $conn->query($sql);

// Verificar si hay resultados
if ($result->num_rows > 0) {
    // Obtener el total de clientes desde el resultado
    $row = $result->fetch_assoc();
    $totalClientes = $row['totalClientes'];
} else {
    $totalClientes = 0; // En caso de que no haya registros
}

// Consulta para el ingreso total generado
$sqlIngresosGenerados = "SELECT SUM(Total) AS ingresosGenerados FROM Pago";
$resultIngresos = $conn->query($sqlIngresosGenerados);
$ingresosGenerados = $resultIngresos->fetch_assoc()['ingresosGenerados'] ?? 0;

// Consulta para total de ventas diarias
$sqlVentasDiarias = "SELECT SUM(p.Total) AS ventasDiarias
                     FROM Pago p
                     JOIN Pedido pe ON p.CodPago = pe.CodPago
                     WHERE DATE(pe.Fecha) = CURDATE()";
$resultDiarias = $conn->query($sqlVentasDiarias);
$ventasDiarias = $resultDiarias->fetch_assoc()['ventasDiarias'] ?? 0;

// Consulta para total de ventas semanales
$sqlVentasSemanales = "SELECT SUM(p.Total) AS ventasSemanales
                       FROM Pago p
                       JOIN Pedido pe ON p.CodPago = pe.CodPago
                       WHERE YEARWEEK(pe.Fecha, 1) = YEARWEEK(CURDATE(), 1)";
$resultSemanales = $conn->query($sqlVentasSemanales);
$ventasSemanales = $resultSemanales->fetch_assoc()['ventasSemanales'] ?? 0;

// Consulta para total de ventas mensuales
$sqlVentasMensuales = "SELECT SUM(p.Total) AS ventasMensuales
                       FROM Pago p
                       JOIN Pedido pe ON p.CodPago = pe.CodPago
                       WHERE MONTH(pe.Fecha) = MONTH(CURDATE()) AND YEAR(pe.Fecha) = YEAR(CURDATE())";
$resultMensuales = $conn->query($sqlVentasMensuales);
$ventasMensuales = $resultMensuales->fetch_assoc()['ventasMensuales'] ?? 0;

// Consulta para obtener los productos más vendidos
$sqlProductosMasVendidos = "SELECT prod.CodProducto, prod.Nombre, prod.Tipo, prod.Precio, prod.Imagen, SUM(i.Cantidad) AS totalVendidos
                            FROM Producto prod
                            JOIN Incluye i ON prod.CodProducto = i.CodProducto
                            GROUP BY prod.CodProducto
                            ORDER BY totalVendidos DESC
                            LIMIT 5";
$resultProductosMasVendidos = $conn->query($sqlProductosMasVendidos);


?>



<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>MunayArt Dashbord</title>
</head>

<body>

    <!--SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class="bx bxs-smile"></i>
            <span class="text">MunayArt</span>
        </a>

        <ul class="side-menu top">
            <li class="active">
                <a href="#">
                    <i class="bx bxs-dashboard"></i>
                    <span class="text">Tablero</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <i class="bx bxs-shopping-bag-alt"></i>
                    <span class="text">Usuario</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="bx bxs-doughnut-chart"></i>
                    <span class="text">Productos</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="bx bxs-message-dots"></i>
                    <span class="text">Comunidades</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="bx bxs-group"></i>
                    <span class="text">Entregas</span>
                </a>
            </li>
        </ul>

        <ul class="side-menu">
            <li>
                <a href="#">
                    <i class="bx bxs-cog"></i>
                    <span class="text">Paramétres</span>
                </a>
            </li>

            <li>
                <a href="#" class="logout">
                    <i class="bx bxs-log-out-circle"></i>
                    <span class="text">Deconectar</span>
                </a>
            </li>
        </ul>
    </section>
    <!--SIDEBAR END-->


    <!--Contenu-->
    <section id="content">
        <!--navbar-->
        <nav>
            <i class="bx bx-menu"></i>
            <a href="#" class="nav-link">Categorias</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="buscar...">
                    <button type="submit" class="search-btn"><i class="bx bx-search"></i> </button>

                </div>
            </form>
            <input type="checkbox" id="swith-mode" hidden>
            <label for="swith-mode" class="swith-mode"></label>
            <a href="#" class="notification">
                <i class="bx bxs-bell"></i>
                <span class="num">3</span>
            </a>
            <a href="#" class="profile">
                <img src="img/profil.png" alt="Photo profil">
            </a>
        </nav>
        <!--navbar end-->

        <!--Main-->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Dashbord</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="#">Dashbord</a>
                        </li>
                        <li><i class="bx bx-chevron-right"></i></li>
                        <li>
                            <a class="active" href="#">Inicio</a>
                        </li>
                    </ul>
                </div>
                <a href="#" class="btn-download">
                    <i class="bx bxs-cloud-download"></i>
                    <span class="text">Descargar PDF</span>
                </a>
            </div>


            <ul class="box-info">
                <li>
                    <i class="bx bxs-calendar-check"></i>
                    <span class="text">
                        <h3>500</h3>
                        <p>Nuevos Pedidos</p>
                    </span>
                </li>
                <li>
                    <i class="bx bxs-group"></i>
                    <span class="text">
                        <h3><?php echo $totalClientes; ?></h3>
                        <p>Clientes</p>
                    </span>
                </li>
                <!-- Mostrar total de ventas diarias, semanales y mensuales en HTML -->
                <li>
                    <i class="bx bxs-dollar-circle"></i>
                    <span class="text">
                        <h3>Bs.<?php echo $ingresosGenerados; ?></h3>
                        <p>Ingresos Generados</p>
                    </span>
                </li>
                <li>
                    <i class="bx bxs-dollar-circle"></i>
                    <span class="text">
                        <h3>Bs.<?php echo $ventasDiarias; ?></h3>
                        <p>Ventas Diarias</p>
                    </span>
                </li>
                <li>
                    <i class="bx bxs-dollar-circle"></i>
                    <span class="text">
                        <h3>Bs.<?php echo $ventasSemanales; ?></h3>
                        <p>Ventas Semanales</p>
                    </span>
                </li>
                <li>
                    <i class="bx bxs-dollar-circle"></i>
                    <span class="text">
                        <h3>Bs.<?php echo $ventasMensuales; ?></h3>
                        <p>Ventas Mensuales</p>
                    </span>
                </li>
            </ul>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Productos Más Vendidos</h3>
                        <i class="bx bx-search"></i>
                        <i class="bx bx-filter"></i>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Imagen</th>
                                <th>CodProducto</th>
                                <th>Nombre</th>
                                <th>Tipo</th>
                                <th>Precio</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($producto = $resultProductosMasVendidos->fetch_assoc()): ?>
                                <tr>
                                    <td><img src="img/<?php echo $producto['Imagen']; ?>"
                                            alt="<?php echo $producto['Nombre']; ?>"></td>
                                    <td><?php echo $producto['CodProducto']; ?></td>
                                    <td><?php echo $producto['Nombre']; ?></td>
                                    <td><?php echo $producto['Tipo']; ?></td>
                                    <td>$<?php echo $producto['Precio']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>


            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Pedidos recientes</h3>
                        <i class="bx bx-search"></i>
                        <i class="bx bx-filter"></i>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Usuario</th>
                                <th>Fecha de pedido</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="img/p1.png" alt="Profil 1">
                                    <p>Marie</p>
                                </td>
                                <td>14-08-2024</td>
                                <td><span class="status completed">Entregado</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="img/p2.png" alt="Profil 2">
                                    <p>Bineta</p>
                                </td>
                                <td>14-08-2024</td>
                                <td><span class="status pending">Enviado</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="img/p3.png" alt="Profil 3">
                                    <p>Ibrahim</p>
                                </td>
                                <td>14-08-2024</td>
                                <td><span class="status process">En proceso</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="img/p4.png" alt="Profil 4">
                                    <p>Maimouna</p>
                                </td>
                                <td>14-08-2024</td>
                                <td><span class="status pending">Pendientes</span></td>
                            </tr>

                        </tbody>
                    </table>
                </div>


                <div class="todo">
                    <div class="head">
                        <h3>Lista de verificación</h3>
                        <i class="bx bx-plus"></i>
                        <i class="bx bx-filter"></i>
                    </div>
                    <ul class="todo-list">
                        <li class="completed">
                            <p>A Faire</p>
                            <i class="bx bx-dots-vertical-rounded"></i>
                        </li>
                        <li class="not-completed">
                            <p>A Faire</p>
                            <i class="bx bx-dots-vertical-rounded"></i>
                        </li>
                        <li class="completed">
                            <p>A Faire</p>
                            <i class="bx bx-dots-vertical-rounded"></i>
                        </li>
                        <li class="not-completed">
                            <p>A Faire</p>
                            <i class="bx bx-dots-vertical-rounded"></i>
                        </li>
                        <li class="completed">
                            <p>A Faire</p>
                            <i class="bx bx-dots-vertical-rounded"></i>
                        </li>
                    </ul>
                </div>
            </div>
        </main>
        <!--Main end-->
    </section>
    <!--Main end-->

    <!--JavaScrip-->
    <script src="script.js"></script>
</body>

</html>