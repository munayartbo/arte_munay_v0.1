<?php
include '../../controllers/db_connection.php';

// Obtener el código del pedido enviado por el formulario
$codPedido = $_POST['CodPedido'];
$codDelivery = $_SESSION['CodDelivery']; // Suponiendo que el delivery ha iniciado sesión

// Actualizar el estado del pedido y asignarlo al delivery
$sql = "UPDATE Pedido SET Estado = 'aceptado', CodDelivery = ? WHERE CodPedido = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $codDelivery, $codPedido);

if ($stmt->execute()) {
    echo "Pedido aceptado exitosamente.";
    // Redirigir a la vista de pedidos del delivery
    header("Location: vista_pedidos_delivery.php");
} else {
    echo "Error al aceptar el pedido.";
}
?>
