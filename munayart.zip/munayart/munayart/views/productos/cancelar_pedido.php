<?php
include '../../controllers/db_connection.php';

// Obtener el código del pedido enviado por el formulario
$codPedido = $_POST['CodPedido'];

// Actualizar el estado del pedido a 'cancelado'
$sql = "UPDATE Pedido SET Estado = 'cancelado' WHERE CodPedido = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $codPedido);

if ($stmt->execute()) {
    echo "Pedido cancelado exitosamente.";
    // Redirigir según quien esté cancelando
    if ($_SESSION['rol'] == 'cliente') {
        header("Location: vista_pedidos_cliente.php");
    } else {
        header("Location: vista_pedidos_delivery.php");
    }
} else {
    echo "Error al cancelar el pedido.";
}
?>
